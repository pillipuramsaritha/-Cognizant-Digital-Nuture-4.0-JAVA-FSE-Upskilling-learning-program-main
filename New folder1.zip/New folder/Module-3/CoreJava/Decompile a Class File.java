Write any Java class, e.g., Test.java

Compile it: javac Test.java

Open Test.class in JD-GUI or use a tool like CFR:


java -jar cfr.jar Test.class
