it contains HTML5
CSS3
JAVASCRIPT
Bootstrap 5
Java Script Build tools
